package initGAME;

import org.academiadecodigo.simplegraphics.graphics.Rectangle;

public class Animator implements Runnable{

    private Rectangle rectangle;
    @Override
    public void run() {

    }




}
