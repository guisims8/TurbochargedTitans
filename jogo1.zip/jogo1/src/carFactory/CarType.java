package carFactory;

public enum CarType {
    YELLOW,
    GREEN,
    RED,
    SCOOTER,
}
